import { useState } from 'react'

const questions = [
  {
    question: "¿Cuál es el principal gas responsable del efecto invernadero?",
    options: ["Oxígeno", "CO₂", "Nitrógeno", "Ozono"],
    answer: "CO₂",
    explanation: "El CO₂ (dióxido de carbono) es uno de los principales gases responsables del calentamiento global.",
  },
  {
    question: "¿Cuál de estas acciones ayuda a reducir tu huella de carbono?",
    options: ["Usar el coche para todo", "Plantar árboles", "Comer más carne", "Dejar luces encendidas"],
    answer: "Plantar árboles",
    explanation: "Plantar árboles ayuda a absorber CO₂ del aire, reduciendo tu huella de carbono.",
  },
];

export default function App() {
  const [current, setCurrent] = useState(0);
  const [score, setScore] = useState(0);
  const [feedback, setFeedback] = useState("");
  const [completed, setCompleted] = useState(false);

  const question = questions[current];

  const handleAnswer = (option) => {
    if (option === question.answer) {
      setScore(score + 1);
      setFeedback("✅ Correcto. ¡El planeta mejora!");
    } else {
      setFeedback("❌ Incorrecto. " + question.explanation + " El planeta se deteriora.");
    }

    setTimeout(() => {
      if (current + 1 < questions.length) {
        setCurrent(current + 1);
        setFeedback("");
      } else {
        setCompleted(true);
      }
    }, 2500);
  };

  const planetHealth = (score / questions.length) * 100;

  const ending =
    planetHealth === 100
      ? "🌍 Has salvado el planeta con excelencia."
      : planetHealth >= 50
      ? "🌱 El planeta se ha recuperado parcialmente. Sigue aprendiendo."
      : "🌪️ El planeta sufre. Puedes intentarlo de nuevo.";

  return (
    <div style={{ minHeight: '100vh', padding: 20, background: 'linear-gradient(to bottom, #d4fc79, #96e6a1)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
      <h1 style={{ fontSize: 32, fontWeight: 'bold', marginBottom: 20 }}>EcoMisión 🌍</h1>
      <progress value={planetHealth} max={100} style={{ width: '100%', maxWidth: 400, marginBottom: 20 }} />
      {!completed ? (
        <div style={{ background: 'white', padding: 20, borderRadius: 12, boxShadow: '0 0 10px rgba(0,0,0,0.1)', maxWidth: 400, width: '100%' }}>
          <h2 style={{ fontSize: 20, marginBottom: 10 }}>{question.question}</h2>
          {question.options.map((option) => (
            <button key={option} onClick={() => handleAnswer(option)} style={{ marginBottom: 10, padding: 10, width: '100%', borderRadius: 6 }}>
              {option}
            </button>
          ))}
          {feedback && <p style={{ marginTop: 10 }}>{feedback}</p>}
        </div>
      ) : (
        <div style={{ textAlign: 'center', background: 'white', padding: 20, borderRadius: 12, boxShadow: '0 0 10px rgba(0,0,0,0.1)', maxWidth: 400 }}>
          <h2 style={{ fontSize: 24, fontWeight: 'bold', marginBottom: 10 }}>Resultado final</h2>
          <p style={{ fontSize: 18, marginBottom: 20 }}>{ending}</p>
          <button onClick={() => location.reload()} style={{ padding: 10, borderRadius: 6 }}>Reintentar</button>
        </div>
      )}
    </div>
  );
}
